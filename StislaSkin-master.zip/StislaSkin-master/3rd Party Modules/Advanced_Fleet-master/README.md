Advanced_Fleet
==============

For phpVMS, Advanced Fleet is a module that renders detailed information on each aircraft in an virtual airline's fleet.
