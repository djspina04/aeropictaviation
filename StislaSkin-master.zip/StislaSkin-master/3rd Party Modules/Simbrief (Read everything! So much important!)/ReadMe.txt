SimBrief Phpvms Module created by Vangelis Boulasikis (Baggelis.com)


Installation Instructions

1. Copy files to their coresponding folders

2.Edit simbrief.apiv1.php in core/modules/SimBrief
and add your API Key that you requested by email from Simbrief
     Information on how to get the API: https://forum.phpvms.net/topic/21388-sim-brief-for-phpvms/

3.Edit simbrief.apiv1.js in lib/js
and add your full website addres in the apropiate location

For any question you are free to open a new post in the phpvms forum 
I will not answer to pm and email's