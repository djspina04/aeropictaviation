This module created by phpmods and can be used only with phpVMS (www.phpvms.net).

///////////////////////////////////////////////
///  Pilot Career Page v1.1 by php-mods.eu  ///
///            Author php-mods.eu           ///
///            Packed at 3/1/2013           ///
///     Copyright (c) 2013, php-mods.eu     ///
///////////////////////////////////////////////

Registered Under Creative Commons Attribution-Noncommercial-Share Alike  3.0 Unported License

Version 1.0 (27.11.2012) - Module Created
Version 1.1 (03.01.2013) - Module Updated; Added the aicraft column on the ranks table