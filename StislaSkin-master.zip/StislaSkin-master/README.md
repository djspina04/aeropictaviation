# StislaSkin
 StislaSkin is a skin for phpVMS, developed by Carlos Eduardo. StislaSkin was developed using the "Stisla Admin Template" admin panel, created by Muhamad Nauval Azhar (getstisla.com).

# Warning
This is a beta release. If you find an error or bug, please post an comment here or contant us here. It is human to err!

# Attribution
As per the phpVMS license and the condition for using this skin, you must keep the ‘CrewCenter by Carlos Eduardo | Powered by phpVMS’ attribution in the footer. And the most important: You also need to maintain the following credits from the creator of this admin panel: "Design By Muhamad Nauval Azhar"

# Installation
Because of the great process of steps for installing the skin, I put the installation and other important things in the documentation, where you can find in: https://carlosmfreitas2409.github.io/StislaSkin/

# Contact
You can contact me through the phpVMS forum (CarlosEduardo2409), I usually reply, but if I don't answer, you can call me on my Instagram (carlosmeduardo), which I'm sure I'll answer. You can also call me by email (carlosmfreitas05@gmail.com), but the chance of my reply is already less. It's even better to get in touch via StislaSkin post on the phpVMS forum, in addition to being able to help you, the community can also help you. In addition, if someone has the same error, the answer will already be in the forum.

StislaSkin post (phpVMS Forum): https://forum.phpvms.net/topic/27189-skin-free-stislaskin-2020-designed-for-phpvms-5572-proavia-v10-w-leaflet-book-by-map/
