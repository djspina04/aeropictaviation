# phpVMS ACARS Module

## Requirements

- PHP 5.4 minimum

## Installation

### Files

Place the `API` folder into your `core/modules` folder. In your `core/app.config.php` file, at the bottom, add:

```php
require_once(__DIR__.'/modules/API/config.php');
```

### Database

Run this

```sql

```

## Links

To link to the ACARS config for download, use:

```
```
