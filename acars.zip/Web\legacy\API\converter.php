<?php
/**
 *
 */

class ApiConverter
{
    /**
     * @param $ac
     * @return array
     */
    public function aircraft($ac)
    {
        return [
            'id'           => $ac->id,
            'name'         => $ac->fullname,
            'registration' => $ac->registration,
        ];
    }

    /**
     * @param $airline
     * @return array
     */
    public function airline($airline)
    {
        return [
            'id'   => $airline->id,
            'icao' => $airline->code,
            'iata' => $airline->code,
            'name' => $airline->name,
        ];
    }

    /**
     * @param $s
     * @return array
     */
    public function schedule($s)
    {
        return [
            'id'             => $s->id,
            'ident'          => $s->code.$s->flightnum,
            'flight_number'  => $s->flightnum,
            'route_code'     => '',
            'route_leg'      => '',
            'dpt_airport_id' => $s->depicao,
            'arr_airport_id' => $s->arricao,
            'dpt_time'       => $s->deptime,
            'arr_time'       => $s->arrtime,
            'route'          => $s->route,
            'level'          => $s->flightlevel,
            'distance'       => [
                'nmi' => $s->distance,
            ],
            'flighttime'     => $s->flighttime * 60, // to mins
        ];
    }

    /**
     * Return in a fake subfleet list
     * @param $aircraft_list
     * @return array
     */
    public function subfleet($aircraft_list)
    {
        $sf = [
            [
                'id'       => 1,
                'aircraft' => [],
            ]
        ];

        foreach($aircraft_list as $ac) {
            $sf[0]['aircraft'][] = $this->aircraft($ac);
        }

        return $sf;
    }
}
