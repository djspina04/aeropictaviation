<?php
/**
 * Copyright (C) phpVMS - All Rights Reserved
 * Unauthorized copying or distribution of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nabeel Shahzad <nabeel@phpvms.net>
 */

class ApiModels
{

}
