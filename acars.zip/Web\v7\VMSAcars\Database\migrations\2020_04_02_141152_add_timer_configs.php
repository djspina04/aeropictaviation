<?php

use Modules\VMSAcars\Contracts\Migration;

class AddTimerConfigs extends Migration
{
    public function up()
    {
        $this->seedFile('settings.yml');
    }

    public function down()
    {

    }
}
