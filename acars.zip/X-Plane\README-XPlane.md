﻿# X-Plane Plugin

## Installation Instructions

Copy the `AcarsConnect` folder into  your `Resources\plugins` folder.