<?php


 /**
  * Source: https://www.popmartian.com/tipsntricks/2015/07/14/howto-use-php-getallheaders-under-fastcgi-php-fpm-nginx-etc/
  */
  if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }

        return $headers;
    }
}


/**
     *
     */
if (!function_exists('phpvms_svc_date_compare')) {
    function phpvms_svc_date_compare($a, $b)
    {
        $t1 = strtotime($a->created_at);
        $t2 = strtotime($b->created_at);
        return $t1 - $t2;
    }
}
