<?php
/**
 * Copyright (C) phpVMS - All Rights Reserved
 * Unauthorized copying or distribution of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nabeel Shahzad <nabeel@phpvms.net>
 */

require_once __DIR__.'/sparrow.php';

class ApiService
{
    private $db;

    /**
     * ApiService constructor.
     * @throws Exception
     */
    public function __construct()
    {
        $this->db = new Sparrow();
        $this->db->setDb(DB::$DB->dbh);
    }

    /**
     *
     * @throws ErrorException
     */
    public function getUserId($api_key)
    {
        if (preg_match('/^([A-Za-z]*)(.*)(\d*)/', $api_key, $matches) > 0) {
            $id = trim($matches[2]);
            /** @noinspection OpAssignShortSyntaxInspection */
            $id = $id - (int) Config::Get('PILOTID_OFFSET');
            return $id;
        }

        // just throw an exception to bail out
        throw new ErrorException('Invalid API key', 403);
    }

    /**
     *
     */
    public function sortByDateTime(&$list)
    {
        usort($list, 'phpvms_svc_date_compare');
    }

    /**
     * Convert the minutes from
     * @param $time
     * @return string
     */
    public function minutesToHM($time)
    {
        $hours = floor($time / 60);
        $minutes = ($time % 60);
        return $hours.':'.$minutes;
    }

    /**
     * @param $hm
     * @return float|int
     */
    public function HMToMinutes($hm)
    {
        $parts = explode('.', $hm);
        $total = (int) $parts[0] * 60;
        $total += (int) $parts[1];

        return $total;
    }

    /**
     * Check if a PIREP is a duplicate...
     * @param $data
     * @return null
     */
    public function checkForDupe($data)
    {
        $pirep = $this->pirep_v7_to_legacy($data);
        $tl = Config::Get('PIREP_TIME_CHECK');
        if (empty($tl)) {
            $tl = 1;
        }

        $r = $this->db
            ->from(TABLE_PREFIX.'pireps')
            ->where('DATE_SUB(NOW(), INTERVAL '.$tl.' MINUTE) <= `submitdate`')
            ->where([
                'pilotid'   => $pirep['pilotid'],
                'code'      => $pirep['code'],
                'flightnum' => $pirep['flightnum'],
            ])
            ->select(['pirepid'])
            ->one();

        if (count($r) > 0) {
            return $r['pirepid'];
        }

        return null;
    }

    /**
     *
     */
    public function pirep_get($pirep_id)
    {
        return $this->pirep_v7_to_legacy($pirep_id);
    }

    /**
     * @param $field_title
     * @return mixed
     */
    public function add_pirep_field($field_title)
    {
        $name = strtoupper(str_replace(' ', '_', $field_title));

        $field = $this->db
            ->from(TABLE_PREFIX.'pirepfields')
            ->where('name', $name)
            ->select()->one();

        if (count($field) === 0) {
            $this->db
                ->from(TABLE_PREFIX.'pirepfields')
                ->insert([
                    'title'   => $field_title,
                    'name'    => $name,
                    'type'    => 'text',
                    'options' => '',
                ])->execute();
            $field_id = $this->db->insert_id;
        } else {
            $field_id = $field['fieldid'];
        }

        return $field_id;
    }

    /**
     * @param $field_id
     * @param $value
     */
    public function add_pirep_value($pirep_id, $field_id, $value)
    {
		if($value === "null" || $value === null) {
			return;
		}

        $q = [
            'pirepid' => $pirep_id,
            'fieldid' => $field_id,
        ];

        $field_val = $this->db
            ->from(TABLE_PREFIX.'pirepvalues')
            ->where($q)->one();

        //var_dump($value);
        if (count($field_val) > 0) {
            $r = $this->db
                ->from(TABLE_PREFIX.'pirepvalues')
                ->where('id', $field_val['id'])
                ->update(['value' => $value])
                ->execute();
        } else {
            $q['value'] = $value;
            $this->db
                ->from(TABLE_PREFIX.'pirepvalues')
                ->insert($q)
                ->execute();
        }
    }

    /**
     * @param $fields
     */
    public function update_fields($pirep_id, $fields)
    {
        foreach ($fields as $field_title => $value) {
            $field_id = $this->add_pirep_field($field_title);
            $this->add_pirep_value($pirep_id, $field_id, $value);
        }
    }

    /**
     * There isn't a "prefile" or anything in the common data
     * So just create a new PIREP with the IN_PROGRESS status
     * depending on what fields are passed in
     * @param $data
     * @return array
     * @throws ErrorException
     */
    public function pirep_prefile($data)
    {
        /*
        ex incoming:
        - ignore fares
        - fields:
            1. find/update in pirepfields table
            2. update value in pirepvalues table
        - set to PIREP_INPROGRESS

        $pirep = [
            'airline_id' => $airline->id,
            'aircraft_id' => $aircraft->id,
            'dpt_airport_id' => $airport->icao,
            'arr_airport_id' => $airport->icao,
            'flight_number' => '6000',
            'level' => 38000,
            'planned_distance' => 400,
            'planned_flight_time' => 120,
            'route' => 'POINTA POINTB',
            'source_name' => 'UnitTest',
            'fields' => [
                'custom_field' => 'custom_value',
            ],
            'fares' => [
                [
                    'id' => $fare->id,
                    'count' => $fare->capacity,
                ],
            ],
        ] */

        // Do our own check if it's a duplicate
        // just grab the ID if it is and return it (mimics v7 behavior)
        $id = $this->checkForDupe($data);
        if ($id === null) {
            // Try filing it... and placeholders for default fields
            // And bypass the PIREPData call, since it does a ton of
            // post-file tasks
            $pirep = array_merge([
                'distance'         => 0,
                'flighttime'       => '0',
                'flighttime_stamp' => '00:00:00',
                'fuelused'         => 0,
                'log'              => '',
                'load'             => 0,
                'rawdata'          => '',
                'route'            => '',
                'route_details'    => '',
                'exported'         => 0,
                'accepted'         => PIREP_INPROGRESS,
            ], $this->pirep_v7_to_legacy($data));

            try {
                $r = $this->db
                    ->from(TABLE_PREFIX.'pireps')
                    ->insert($pirep)
                    ->execute();
            } catch (\Exception $e) {
                throw new ErrorException(
                    $e->getMessage(),
                    500);
            }

            if (!$r) {
                throw new ErrorException(
                    'Error prefiling: '.PIREPData::$lasterror,
                    500);
            }

            $id = $this->db->insert_id;
        }

        # update fields if req
        if (property_exists($data, 'fields')) {
            $this->update_fields($id, $data->fields);
        }

        return $this->pirep_legacy_to_v7($id);
    }

    /**
     * Update any new fields, etc
     */
    public function pirep_update($pirep_id, $data)
    {
        $this->pirep_update_record($pirep_id, $data);
        if (property_exists($data, 'fields')) {
            $this->update_fields($pirep_id, $data->fields);
        }

        return $this->pirep_legacy_to_v7($pirep_id);
    }

    /**
     *
     * @throws ErrorException
     */
    public function pirep_file($pirep_id, $data)
    {
        $extra = [
            'accepted' => PIREP_PENDING,
            'submitdate' => 'NOW()',
        ];

        $this->pirep_update_record($pirep_id, $data, $extra);
        if (property_exists($data, 'fields')) {
            $this->update_fields($pirep_id, $data->fields);
        }

        // Run the post file-PIREP tasks from PIREPData.class.php#L802 and down

        PIREPData::populatePIREPFinance($pirep_id, true);
        PIREPData::UpdatePIREPFeed();

        $pirepdata = PIREPData::getReportDetails($pirep_id);
        $pilotinfo = PilotData::getPilotData($data->pilot_id);
        $pilotcode = PilotData::getPilotCode($pilotinfo->code, $pilotinfo->pilotid);
        PilotData::UpdateLastPIREPDate($pilotinfo->pilotid);

        $sub = "A PIREP has been submitted by {$pilotcode} ({$pirepdata->depicao} - {$pirepdata->arricao})";
        $message = "A PIREP has been submitted by {$pilotcode} ({$pilotinfo->firstname} {$pilotinfo->lastname})\n\n"
            ."{$pirepdata->code}{$pirepdata->flightnum}: {$pirepdata->depicao} to {$pirepdata->arricao}\n"
            ."Aircraft: {$pirepdata->aircraft}\n"
            ."Flight Time: {$pirepdata->flighttime}\n"
            ."Filed using: {$pirepdata->source}\n\n"
            ."Comment: {$pirepdata->comment}";

        $email = Config::Get('EMAIL_NEW_PIREP');
        if (empty($email)) {
            $email = ADMIN_EMAIL;
        }

        Util::SendEmail($email, $sub, $message);

        return $this->pirep_legacy_to_v7($pirep_id);
    }

    /**
     * Update any new fields, etc
     * @param $pirep_id
     */
    public function pirep_cancel($pirep_id)
    {
        PIREPData::deleteFlightReport($pirep_id);
    }

    /**
     * Set fields that might have been updated
     * @param       $pirep_id
     * @param       $data
     * @param array $extra_pirep_files
     * @return array
     * @throws ErrorException
     */
    public function pirep_update_record($pirep_id, $data, $extra_pirep_files = [])
    {
        $pirep = array_merge(
            $this->pirep_v7_to_legacy($data),
            $extra_pirep_files);

        try {
            $r = $this->db
                ->from(TABLE_PREFIX.'pireps')
                ->where('pirepid', $pirep_id)
                ->update($pirep)
                ->execute();
        } catch (\Exception $e) {
            throw new ErrorException(
                $e->getMessage(),
                500);
        }

        return $this->pirep_legacy_to_v7($pirep_id);
    }

    /**
     * Convert the v7 PIREP to legacy
     * @param $pirep_id
     * @return array
     */
    public function pirep_legacy_to_v7($pirep_id)
    {
        $pirep = PIREPData::getReportDetails($pirep_id);
        $airline = OperationsData::getAirlineByCode($pirep->code);

        # Get the fields
        $table_fields = $this->db
            ->from(TABLE_PREFIX.'pirepvalues')
            ->leftJoin(TABLE_PREFIX.'pirepfields', [
                TABLE_PREFIX.'pirepfields.fieldid' => TABLE_PREFIX.'pirepvalues.fieldid',
            ])
            ->where(TABLE_PREFIX.'pirepvalues.pirepid', $pirep_id)
            ->select(['title', 'value'])
            ->many();

        $fields = [];
        foreach ($table_fields as $f) {
            $fields[$f['title']] = $f['value'];
        }

        # Get thhe comments
        $comments = [];
        $table_comments = PIREPData::getComments($pirep_id);

        if($table_comments) {
            foreach ($table_comments as $comment) {
                $comments[] = [
                    'id'         => $comment->id,
                    'comment'    => $comment->comment,
                    'created_at' => date('c', $comment->postdate),
                    'user'       => [
                        'id'       => $comment->pilotid,
                        'pilot_id' => $comment->pilotid,
                        'name'     => $comment->firstname.' '.$comment->lastname
                    ]
                ];
            }
        }

        return [
            'id'                  => $pirep->pirepid,
            'airline_id'          => (int) $airline->id,
            'aircraft_id'         => (int) $pirep->aircraftid,
            'dpt_airport_id'      => $pirep->depicao,
            'arr_airport_id'      => $pirep->arricao,
            'flight_number'       => $pirep->flightnum,
            'level'               => $pirep->flightlevel,
            'planned_distance'    => $pirep->distance,
            'planned_flight_time' => $this->HMToMinutes($pirep->flighttime),
            'route'               => $pirep->route,
            'source_name'         => $pirep->source,
            'fields'              => $fields,
            'comments'            => $comments,
        ];
    }

    /**
     * Transform the legacy PIREP into the v7 format. Pass in the v7 object
     * @param $data
     * @return array
     */
    public function pirep_v7_to_legacy($data)
    {
        $pirep = [];

        if (property_exists($data, 'pilot_id')) {
            $pirep['pilotid'] = $data->pilot_id;
        }

        if (property_exists($data, 'airline_id')) {
            $airline = OperationsData::getAirlineByID($data->airline_id);
            $pirep['code'] = $airline->code;
        }

        if (property_exists($data, 'flight_number')) {
            $pirep['flightnum'] = $data->flight_number;
        }

        if (property_exists($data, 'flight_time')) {
            $pirep['flighttime'] = $this->minutesToHM($data->planned_flight_time);
        }

        if (property_exists($data, 'dpt_airport_id')) {
            $pirep['depicao'] = $data->dpt_airport_id;
        }

        if (property_exists($data, 'arr_airport_id')) {
            $pirep['arricao'] = $data->arr_airport_id;
        }

        if (property_exists($data, 'aircraft_id')) {
            $pirep['aircraft'] = $data->aircraft_id;
        }

        if (property_exists($data, 'route')) {
            $pirep['route'] = $data->route;
        }

        if (property_exists($data, 'source_name')) {
            $pirep['source'] = $data->source_name;
        }

        return $pirep;
    }
}
