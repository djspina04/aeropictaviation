~~~~~NOTICE~~~~~
Only compatible with PW engines. Other engines may appear blank.

~~~~~CREDITS~~~~~
A huge thanks to:
@yummy#4490
@SAMMY#1657

for designing and putting this livery together!

~~~~~DISCORD~~~~~
https://discord.gg/KTfGYDMHW9