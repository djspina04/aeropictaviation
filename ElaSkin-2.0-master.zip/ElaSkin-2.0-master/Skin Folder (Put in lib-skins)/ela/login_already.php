<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<?php header('Location:'.SITE_URL.'/index.php'); ?>