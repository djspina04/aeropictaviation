A skin for phpVMS made by one of our developers, Carlos Eduardo.

# Demo
If you want to see a demo of Ela Skin open this link: https://elc.fsvas.co.uk/demo/elaskin/index.php/ (User: ELC0003 / PW: Demo123)

# Warning
This is a beta release. If you find an error or bug, please post an comment here or contant us here.

# Attribution
As per the phpVMS license and the condition for using this skin, you must keep the ‘CrewCenter by ElixarCode | Powered by phpVMS’ attribution in the footer.

# Installation
1. Download phpVMS 5.5 and this skin.
2. Install phpVMS.
3. Create a folder named ‘ela’ in the lib/skins directory of your phpVMS installation.
4. Move all files from this repository into the folder named ‘ela’.
5. Log in to the phpVMS admin center, navigate to ‘General Settings’, then select the ‘ela’ skin.

# Contact
If you have any comments, queries or suggestions, please feel free to email me at carlosmfreitas05@gmail.com
