<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
        </div>
		                <footer class="footer mt-auto">
            <div class="copyright bg-white">
              <p>
                Copyright &copy; <?php echo date('Y') ?> <?php echo SITE_NAME; ?> | Powered by phpVMS | Developed by <a href="https://creationweb.uk">Creation Web</a>
              </p>
            </div>
            <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script>
          </footer>

    </div>
  </div>